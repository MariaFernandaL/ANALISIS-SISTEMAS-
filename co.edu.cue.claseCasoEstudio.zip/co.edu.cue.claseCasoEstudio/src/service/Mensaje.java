package service;

public interface Mensaje{

    /**
     * Descripcion: Este metodo define el envio de un mensaje, se implementa en los compradores con diferente funcionalidad
     * @return
     */
    public String sendMessage();
}

