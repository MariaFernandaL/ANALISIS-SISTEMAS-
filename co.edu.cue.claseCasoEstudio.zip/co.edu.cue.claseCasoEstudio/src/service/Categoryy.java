package service;

public enum Categoryy {
    ACCESORIOELECTRONICO, ACCESORIODECORATIVO, COMPUTADOR, CELULAR
}
